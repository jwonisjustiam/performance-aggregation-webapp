"""Shared spreadsheet services."""
