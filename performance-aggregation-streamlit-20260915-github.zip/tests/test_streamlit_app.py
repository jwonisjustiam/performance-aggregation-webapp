from datetime import date
from pathlib import Path

import pandas as pd
from openpyxl import load_workbook

from processors.weekly_processor import process_weekly
from services.excel_writer import create_result_workbook


ROOT = Path(__file__).parents[1]


def test_manual_date_range_creates_slots_for_arbitrary_file_name() -> None:
    from app import default_slot_rows, expand_date_selection

    target_dates = expand_date_selection((date(2026, 7, 31), date(2026, 8, 2)))
    uploaded_files = [type("Upload", (), {"name": "아무이름.xlsx"})()]
    rows = default_slot_rows("weekly", "external", uploaded_files, target_dates)

    assert target_dates == [date(2026, 7, 31), date(2026, 8, 1), date(2026, 8, 2)]
    assert {row["날짜"] for row in rows} == {"2026-07-31", "2026-08-01", "2026-08-02"}


def test_streamlit_entrypoint_and_docs() -> None:
    app_source = (ROOT / "app.py").read_text(encoding="utf-8")
    requirements = (ROOT / "requirements.txt").read_text(encoding="utf-8")
    readme = (ROOT / "README.md").read_text(encoding="utf-8")

    assert "import streamlit as st" in app_source
    assert "사용 안내" in app_source
    assert "JOB_TYPE_OPTIONS" in app_source
    assert "라이브 SKU 구분 도구" in app_source
    assert "라이브 일정별 구분 도구" in app_source
    assert "입력 SKU 구분 도구" in app_source
    assert "삼성 취합" not in app_source
    assert "위클리 취합" not in app_source
    assert "워치9 사전판매 판매 실적 취합" not in app_source
    assert "selected_job[\"title\"]" in app_source
    assert "raw_files_{job_type}" in app_source
    assert 'with st.expander("입력 SKU 일정·시간 필터"' in app_source
    assert app_source.index('with st.expander("입력 SKU 일정·시간 필터"') > app_source.index("st.title(selected_job")
    assert 'st.tabs([item[0] for item in category_specs])' in app_source
    assert '"Basic 결과"' in app_source
    assert '"웨어러블 결과"' in app_source
    assert '"모바일 ACC 결과"' in app_source
    assert "방송 실적표" not in app_source
    assert "네이버 API 자동 수집" not in app_source
    assert "fetch_raw_data" not in app_source
    assert "네이버 쇼핑라이브 통계 연결" in app_source
    assert "read_live_stats_upload" in app_source
    assert (ROOT / "naver-live-stats-collector" / "manifest.json").exists()
    assert any(line.strip().startswith("streamlit") for line in requirements.splitlines())
    assert "fastapi" not in requirements.lower()
    assert "requests==" not in requirements.lower()
    assert "bcrypt==" not in requirements.lower()
    assert "Streamlit Cloud" in readme


def test_weekly_sample_can_create_downloadable_workbook() -> None:
    raw = pd.DataFrame(
        [["A", "2026-07-07 14:00", "외장하드", "옵션", 1_000_000, 0, "쇼핑라이브"]],
        columns=["주문번호", "결제일시", "상품명", "옵션 정보", "상품가격", "옵션가격", "주문 유입경로"],
    )
    result = process_weekly(raw, "외장하드.xlsx", "external")
    content, validation = create_result_workbook("weekly", result)

    assert validation["valid"] is True

    path = ROOT / "outputs" / "_test_streamlit_weekly.xlsx"
    path.parent.mkdir(exist_ok=True)
    path.write_bytes(content)
    workbook = load_workbook(path, read_only=True)
    try:
        assert workbook.sheetnames == ["회차별 합계"]
    finally:
        workbook.close()
        path.unlink(missing_ok=True)


def test_detail_workbook_sheet_is_created() -> None:
    raw = pd.DataFrame(
        [["A", "2026-07-07 14:00", "갤럭시 워치9", "", "SM-L340NZEAKOO", 1_000_000, 0, "검색"]],
        columns=["주문번호", "결제일시", "상품명", "옵션관리코드", "판매자 상품코드", "상품가격", "옵션가격", "주문 유입경로"],
    )
    from processors.weekly_processor import process_detail

    result = process_detail(raw, "주문.xlsx")
    content, validation = create_result_workbook("detail", result)

    assert validation["valid"] is True

    path = ROOT / "outputs" / "_test_streamlit_detail.xlsx"
    path.parent.mkdir(exist_ok=True)
    path.write_bytes(content)
    workbook = load_workbook(path, read_only=True)
    try:
        assert workbook.sheetnames == ["Basic", "웨어러블", "모바일 ACC"]
    finally:
        workbook.close()
        path.unlink(missing_ok=True)


def test_result_preview_copies_formulas_without_changing_export_numbers():
    from app import build_result_preview

    source = pd.DataFrame({
        "실적 전환율": [0.005, 0, None, 0.12345],
        "달성률": [0.1, 0, None, 1.25],
        "실적 수량": [1, 0, 0, 5],
    })
    original = source.copy(deep=True)
    preview = build_result_preview(source)
    assert preview["실적 전환율"].tolist() == ['=INDEX(AE:AE,ROW())/(INDEX(AD:AD,ROW())*10000)', '=INDEX(AE:AE,ROW())/(INDEX(AD:AD,ROW())*10000)', '=INDEX(AE:AE,ROW())/(INDEX(AD:AD,ROW())*10000)', '=INDEX(AE:AE,ROW())/(INDEX(AD:AD,ROW())*10000)']
    assert preview["달성률"].tolist() == ['=INDEX(AG:AG,ROW())/INDEX(AC:AC,ROW())', '=INDEX(AG:AG,ROW())/INDEX(AC:AC,ROW())', '=INDEX(AG:AG,ROW())/INDEX(AC:AC,ROW())', '=INDEX(AG:AG,ROW())/INDEX(AC:AC,ROW())']
    assert "=INDEX(AE:AE,ROW())/(INDEX(AD:AD,ROW())*10000)\t=INDEX(AG:AG,ROW())/INDEX(AC:AC,ROW())" in preview.to_csv(sep="\t", index=False)
    pd.testing.assert_frame_equal(source, original)
    pd.testing.assert_series_equal(preview["실적 수량"], source["실적 수량"])


def test_result_preview_without_ratio_columns_is_unchanged():
    from app import build_result_preview

    source = pd.DataFrame({"실적 수량": [1, 2]})
    pd.testing.assert_frame_equal(build_result_preview(source), source)


def test_result_preview_formulas_use_destination_row_not_source_index():
    from app import build_result_preview

    source = pd.DataFrame({"실적 전환율": [0.01, None], "달성률": [0.1, 0]}, index=[20, 40])
    preview = build_result_preview(source)
    assert preview.loc[20, "실적 전환율"] == "=INDEX(AE:AE,ROW())/(INDEX(AD:AD,ROW())*10000)"
    assert preview.loc[40, "달성률"] == "=INDEX(AG:AG,ROW())/INDEX(AC:AC,ROW())"
    assert build_result_preview(source.iloc[:0]).empty
